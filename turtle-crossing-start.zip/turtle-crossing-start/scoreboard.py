from turtle import Turtle


FONT = ("Courier", 18, "normal")


class Scoreboard(Turtle):

    def __init__(self):
        super().__init__()
        self.level = 0
        self.hideturtle()
        self.color("black")
        self.penup()
        self.goto(-250, 270)
        self.update_level()

    def update_level(self):
        self.write(f"Level: {self.level}", False, align="center", font=FONT)

    def increase_level(self):
        self.level += 1
        self.clear()
        self.update_level()


class GameOver(Turtle):

    def __init__(self):
        super().__init__()
        self.level = 0
        self.hideturtle()
        self.color("black")
        self.penup()
        self.goto(0, 0)

    def game_over(self):
        self.write("Game Over.", False, align="center", font=FONT)

