import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard, GameOver

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)

POSITIONS = [(300, 0), (300, 30), (300, 60), (300, 90), (300, 120), (300, 150), (300, 180), (300, 210),
             (300, -30), (300, -60), (300, -90), (300, -120), (300, -150), (300, -180), (300, -210)]

player = Player()
car_manager = CarManager()
scoreboard = Scoreboard()
game_over = GameOver()


screen.listen()
screen.onkeypress(player.move, "Up")

game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()
    car_manager.create_car()
    car_manager.move_cars()

    # Detect if player hit the wall
    if player.ycor() > 288:
        car_manager.level_up()
        player.starting_position()
        scoreboard.increase_level()


    # Detect if player collide with car
    for car in car_manager.all_cars:
        if car.distance(player) < 25:
            game_over.game_over()
            game_is_on = False






screen.exitonclick()