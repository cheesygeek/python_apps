##################### Extra Hard Starting Project ######################

# 1. Update the birthdays.csv

# 2. Check if today matches a birthday in the birthdays.csv

# 3. If step 2 is true, pick a random letter from letter templates and replace the [NAME] with the person's actual name from birthdays.csv

# 4. Send the letter generated in step 3 to that person's email address.


import datetime as dt
import pandas as pd
import os
import random
import smtplib

now = dt.datetime.now()
data = pd.read_csv("birthdays.csv")

my_email = "pythontest.pb@gmail.com"
password = "LeBenie17"

for index, row in data.iterrows():
    if now.day == row[4] and now.month == row[3]:
        files = os.listdir("letter_templates")
        file = random.choice(files)
        fl = open(f"letter_templates/{file}")
        letter = fl.read()
        la = letter.replace("[NAME]", f"{row[0]}")

        with smtplib.SMTP("smtp.gmail.com") as connection:
            connection.starttls()
            connection.login(user=my_email, password=password)
            connection.sendmail(
                from_addr=my_email,
                to_addrs="pythontest.pb@yahoo.com",
                msg=f"Subject:Happy Birthday\n\n{la}")





