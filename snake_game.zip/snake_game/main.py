from turtle import Screen
from snake import Snake
from food import Food
from scoreboard import Scoreboard
import time

screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.title("My Snake Game")
screen.tracer(0)  # turn animation on/off and set delay for update drawings

snaky = Snake()
food = Food()
scoreboard = Scoreboard()

screen.listen()
screen.onkey(snaky.up, "Up")
screen.onkey(snaky.down, "Down")
screen.onkey(snaky. left, "Left")
screen.onkey(snaky.right, "Right")

# get snake to automatically move forwards
game_is_on = True
while game_is_on:
    screen.update()  # Perform a update when tracer is turned off
    time.sleep(0.1)
    snaky.move_snake()

    # Detect collision with food using the "distance" method
    if snaky.head.distance(food) < 15:
        food.refresh()
        snaky.extend()
        scoreboard.increase_score()

    # Detect collision with wall.
    if snaky.head.xcor() > 280 or snaky.head.xcor() < -280 or snaky.head.ycor() > 280 or snaky.head.ycor() < -280:
        scoreboard.reset()
        snaky.reset()

    # Detect collision with tail.
    for segment in snaky.segments[1:]:
        if snaky.head.distance(segment) < 10:
            scoreboard.reset()
            snaky.reset()


screen.exitonclick()
