import requests
import datetime

USERNAME = "patrick17"
TOKEN = "nkwjd79ubrv83hii39unnd"
GRAPH_ID = "graph1"
today = datetime.datetime(2021, 6, 10)
DATE = today.strftime("%Y%m%d")

pixela_endpoint = "https://pixe.la/v1/users"
user_params = {
    "token": TOKEN,
    "username": USERNAME,
    "agreeTermsOfService": "yes",
    "notMinor": "yes",
}

# response = requests.post(url=pixela_endpoint, json=user_params)
# print(response.text)

graph_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs"
graph_config = {
    "id": GRAPH_ID,
    "name": "Cycling Graph",
    "unit": "Km",
    "type": "float",
    "color": "momiji",
}

headers = {
    "X-USER-TOKEN": TOKEN
}

# response = requests.post(url=graph_endpoint, json=graph_config, headers=headers)
# print(response.text)

pixel_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs/{GRAPH_ID}"


pixel_params = {
    "date": DATE,
    "quantity": "19",
}

# response = requests.post(url=pixel_endpoint, json=pixel_params, headers=headers)
# print(response.text)

pixel_update_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs/{GRAPH_ID}/{DATE}"
pixel_update_params = {
    "quantity": "15",
}

# response = requests.put(url=pixel_update_endpoint, json=pixel_update_params, headers=headers)
# print(response.text)

delete_point = f"{pixela_endpoint}/{USERNAME}/graphs/{GRAPH_ID}/{DATE}"
response = requests.delete(url=pixel_update_endpoint, json=pixel_update_params, headers=headers)
print(response.text)
