from turtle import Turtle


ALIGNMENT = "center"
FONT = ("courier", 60, "normal")
FONT2 = ("courier", 20, "normal")


class Scoreboard(Turtle):

    def __init__(self, position):
        super().__init__()
        self.score = 0
        self.color("white")
        self.penup()
        self.goto(position)
        self.hideturtle()
        self.update_scoreboard()

    def update_scoreboard(self):
        self.write(f"{self.score}", False, align=ALIGNMENT, font=FONT)

    def increase(self):
        self.score += 1
        self.clear()
        self.update_scoreboard()


class Line(Turtle):

    def __init__(self):
        super().__init__()
        self.goto(0, -380)
        self.setheading(90)
        self.color("white")
        self.hideturtle()
        for i in range(50):
            self.forward(15)
            self.penup()
            self.forward(5)
            self.pendown()


class WinnerStatus(Turtle):

    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.color("white")

    def winner_a(self):
        self.write("Player A! You are the Winner!! 🥳", False, align=ALIGNMENT, font=FONT2)

    def winner_b(self):
        self.write("Player B! You are the Winner!! 🥳", False, align=ALIGNMENT, font=FONT2)
