from selenium import webdriver

chrome_driver_path = "/Users/patrickbenie/Desktop/Development/chromedriver"
driver = webdriver.Chrome(executable_path=chrome_driver_path)
# https://www.amazon.com/dp/B08SMFZSLQ/ref=
driver.get("https://www.python.org/")
# price = driver.find_element_by_id("priceblock_ourprice")
# print(price.text)

# driver.find_element_by_name()
# driver.find_element_by_class_name()
# driver.find_element_by_css_selector() | when the tag has no form of identification
# driver.find_element_by_xpath() |

# driver.close()
# search_bar = driver.find_element_by_name("q")
# print(search_bar.tag_name)

events_time = driver.find_elements_by_css_selector(".event-widget time")
events_name = driver.find_elements_by_css_selector(".event-widget li a")
events = {}

for n in range(len(events_time)):
    events[n] = {
        "time": events_time[n].text,
        "name": events_name[n].text
    }

print(events)


driver.quit()