import requests
import os
from twilio.rest import Client
from twilio.http.http_client import TwilioHttpClient


account_sid = 'AC5ab691633d94c275d02b2ee7b01c242b'
auth_token = '3cabda841f9ea5ff05bd6d65ba80beff'

api_key = "cf6e4f14b557e60313a1aeaa02c5af45"
my_lat = 5.359952
my_lng = -4.008256

parameters = {
    "lat": my_lat,
    "lon": my_lng,
    "appid": api_key,
    "exclude": "current,minutely,daily"
}

response = requests.get(url="https://api.openweathermap.org/data/2.5/onecall", params=parameters)
response.raise_for_status()
weather_data = response.json()
weather_slice = weather_data["hourly"][:12]
for hour_data in weather_slice:
    condition_code = hour_data["weather"][0]["id"]
    if int(condition_code) < 700:
        will_rain = True

if will_rain:
    client = Client(account_sid, auth_token)
    message = client.messages.create(
        body="It's going to rain today. Remember to bring an ☔",
        from_="+1 806 605 5283",
        to="+225 0171478016"
    )

    print(message.status)

# hour = 0
# zeroth = weather_data["hourly"][hour]["weather"][0]["id"]
# weather_cond_codes = []
# while hour < 13:
#     weather_cond_codes.append(zeroth)
#     hour += 1
#
# print(weather_cond_codes)




