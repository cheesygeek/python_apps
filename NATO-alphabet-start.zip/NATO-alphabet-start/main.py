import pandas as pd

# TODO 1. Create a dictionary in this format:
df = pd.read_csv("nato_phonetic_alphabet.csv")

df_dict = {row.letter: row.code for (index, row) in df.iterrows()}

print(df_dict)

# TODO 2. Create a list of the phonetic ssscode words from a word that the user inputs.


not_translated = True
while not_translated:
    word = input("Word: ").upper()
    try:
        translated = [df_dict[letter] for letter in word]
    except KeyError:
        print("Sorry, only letters in the alphabet please")
    else:
        not_translated = False
        print(translated)


