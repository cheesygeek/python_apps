MENU = {
    "espresso": {
        "ingredients": {
            "water": 50,
            "coffee": 18,
        },
        "cost": 1.5,
    },
    "latte": {
        "ingredients": {
            "water": 200,
            "milk": 150,
            "coffee": 24,
        },
        "cost": 2.5,
    },
    "cappuccino": {
        "ingredients": {
            "water": 250,
            "milk": 100,
            "coffee": 24,
        },
        "cost": 3.0,
    }
}

resources = {
    "water": 300,
    "milk": 200,
    "coffee": 100,
}


def user_choice(choice):
    if choice == "espresso":
        resources["water"] = resources["water"] - MENU["espresso"]["ingredients"]["water"]
        resources["coffee"] = resources["coffee"] - MENU["espresso"]["ingredients"]["coffee"]
    elif choice == "latte":
        resources["water"] = resources["water"] - MENU["latte"]["ingredients"]["water"]
        resources["milk"] = resources["milk"] - MENU["latte"]["ingredients"]["milk"]
        resources["coffee"] = resources["coffee"] - MENU["latte"]["ingredients"]["coffee"]
    elif choice == "cappuccino":
        resources["water"] = resources["water"] - MENU["cappuccino"]["ingredients"]["water"]
        resources["milk"] = resources["milk"] - MENU["cappuccino"]["ingredients"]["milk"]
        resources["coffee"] = resources["coffee"] - MENU["cappuccino"]["ingredients"]["coffee"]


# TODO 4. Check resources sufficient?


def check_resources(choice):
    if choice == "espresso":
        if resources["water"] < MENU["espresso"]["ingredients"]["water"]:
            return "Not enough water!"
        elif resources["coffee"] < MENU["espresso"]["ingredients"]["coffee"]:
            return "Not enough coffee!"
    elif choice == "latte":
        if resources["water"] < MENU["latte"]["ingredients"]["water"]:
            return "Not enough water!"
        elif resources["milk"] < MENU["latte"]["ingredients"]["coffee"]:
            return "Not enough milk!"
        elif resources["coffee"] < MENU["latte"]["ingredients"]["coffee"]:
            return "Not enough coffee!"
    elif choice == "cappuccino":
        if resources["water"] < MENU["cappuccino"]["ingredients"]["water"]:
            return "Not enough water!"
        elif resources["milk"] < MENU["cappuccino"]["ingredients"]["coffee"]:
            return "Not enough milk!"
        elif resources["coffee"] < MENU["cappuccino"]["ingredients"]["coffee"]:
            return "Not enough coffee!"


# TODO 5. Process coins.

prices = {
    "cappuccino_price": 3,
    "latte_price": 2.5,
    "espresso_price": 1.5,
    "quarters": 0.25,
    "dimes": 0.10,
    "nickels": 0.05,
    "pennies": 0.01
}
money_made = 0


def coins_processing(quarters, dimes, nickels, pennies, item_price):
    global money_made
    total = quarters + dimes + nickels + pennies
    if total < item_price:
        print("Not enough coins. Money returned")
    else:
        change = total - item_price
        money_made += item_price

    return f"Total inserted = {total:.2f}$ and this is your change {change:.2f}$" \
           f"This the money we made {money_made:.2f}$. "


# TODO 1. Prompt user by asking “What would you like? (espresso/latte/cappuccino): ”
run = True
while run:
    coffee_choice = input("What would you like? (espresso/latte/cappuccino):").lower()
    # TODO 3. Print report.
    if coffee_choice == "report":
        print(f'''
        Water = {resources["water"]}ml
        Milk = {resources["milk"]}ml
        Coffee = {resources["coffee"]}g
        Money = {money_made}$''')

    print("PLease insert coins.")
    q = float(input("How many quarters?: "))
    d = float(input("How many dimes?: "))
    n = float(input("How many nickels?: "))
    p = float(input("How many pennies?: "))

    q *= prices["quarters"]
    d *= prices["dimes"]
    n *= prices["nickels"]
    p *= prices["pennies"]

    if check_resources(coffee_choice) == "Not enough water!":
        run = False
        print(check_resources(coffee_choice))
        print("Please refill water!")
    elif check_resources(coffee_choice) == "Not enough milk!":
        run = False
        print(check_resources(coffee_choice))
        print("Please refill milk!")
    elif check_resources(coffee_choice) == "Not enough coffee!":
        run = False
        print(check_resources(coffee_choice))
        print("Please refill coffee beans!")
    else:
        user_choice(coffee_choice)
        if coffee_choice == "cappuccino":
            print(coins_processing(q, d, n, p, prices["cappuccino_price"]))
        elif coffee_choice == "latte":
            print(coins_processing(q, d, n, p, prices["latte_price"]))
        elif coffee_choice == "espresso":
            print(coins_processing(q, d, n, p, prices["espresso_price"]))




    # TODO 2. Turn off the Coffee Machine by entering “off” to the prompt.


# TODO 6. Check transaction successful?
# TODO 7. Make Coffee.

